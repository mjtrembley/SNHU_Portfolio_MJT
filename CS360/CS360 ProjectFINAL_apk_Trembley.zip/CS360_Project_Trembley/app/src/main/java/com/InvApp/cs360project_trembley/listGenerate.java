package com.InvApp.cs360project_trembley;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;


public class listGenerate  extends BaseAdapter {
    private final Activity context;
    private PopupWindow popwindow;
    ArrayList<Items> items;
    ItemDB itemDatabase;
    Drawable border;



    public listGenerate(Activity context, ArrayList<Items> items, ItemDB itemDatabase) {
        this.context = context;
        this.items = items;
        this.itemDatabase = itemDatabase;
    }

    public static class ViewHolder {
        TextView itemNameTV, currentTV, descriptionTV;
        ImageButton editButton;
        Drawable border;
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int i) {
        return i;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View v, ViewGroup parent) {
        View row = v;
        LayoutInflater inflater = context.getLayoutInflater();
        ViewHolder vh;

        if (v == null) {
            vh = new ViewHolder();
            row = inflater.inflate(R.layout.item_template, null, true);

            vh.itemNameTV = row.findViewById(R.id.itemName);
            vh.currentTV = row.findViewById(R.id.itemCurrentQuantity);
            vh.editButton = row.findViewById(R.id.editButton);
            vh.descriptionTV = row.findViewById(R.id.itemDescription);

            row.setTag(vh);
        } else {
            vh = (ViewHolder) v.getTag();
        }


        vh.itemNameTV.setText("" + items.get(i).getName());
        vh.currentTV.setText(items.get(i).getCurrentQuantity());
        vh.descriptionTV.setText(items.get(i).getDesc());


        // Check is the cell value is zero to change color and send SMS
        String value = vh.currentTV.getText().toString().trim();
        if (value.equals("0")) {
            // Change text color of item qty cell if value is zero
            vh.currentTV.setTextColor(Color.RED);
            homeActivity.SendText(context.getApplicationContext());
        } else {
            // Change and text color of item qty cell to default
            vh.currentTV.setTextColor(Color.BLACK);
        }

        final int position = i;

        vh.editButton.setOnClickListener(view -> editItem(position));

        return row;
    }

    // create page to edit an item
    public void editItem(final int i) {
        LayoutInflater inflater = context.getLayoutInflater();
        View layout = inflater.inflate(R.layout.activity_edit, context.findViewById(R.id.editLayout));
        popwindow = new PopupWindow(layout, 1500, 1800, true);
        popwindow.showAtLocation(layout, Gravity.CENTER, 0, 0);

        EditText editItemName = layout.findViewById(R.id.addItemNameEdit);
        EditText editItemDesc = layout.findViewById(R.id.addItemDescEdit);
        EditText editItemQty = layout.findViewById(R.id.addCurrQuantityEdit);
        EditText editItemAlert = layout.findViewById(R.id.addAlertQuantityEdit);

        editItemName.setText(items.get(i).getName());
        editItemDesc.setText(items.get(i).getDesc());
        editItemQty.setText(items.get(i).getCurrentQuantity());
        editItemAlert.setText(items.get(i).getAlertQuantity());

        Button save = layout.findViewById(R.id.confirmChangesEdit);
        Button delete = layout.findViewById(R.id.deleteButton);

        save.setOnClickListener(view -> {
            String itemName = editItemName.getText().toString();
            String itemDesc = editItemDesc.getText().toString();
            String itemQty = editItemQty.getText().toString();
            String itemAlert = editItemAlert.getText().toString();

            Items item = items.get(i);
            item.setName(itemName);
            item.setDesc(itemDesc);
            item.setCurrentQuantity(itemQty);
            item.setAlertQuantity(itemAlert);

            itemDatabase.updateItem(item);
            items = (ArrayList<Items>) itemDatabase.getAllItems();
            notifyDataSetChanged();

            Toast.makeText(context, "Item Updated", Toast.LENGTH_SHORT).show();
            popwindow.dismiss();
        });

        delete.setOnClickListener(view -> {
            itemDatabase.deleteItem(items.get(i));

            items = (ArrayList<Items>) itemDatabase.getAllItems();
            notifyDataSetChanged();
            Toast.makeText(context, "Item Deleted", Toast.LENGTH_SHORT).show();
            int itemsCount = itemDatabase.getItemsCount();
            TextView TotalItems = context.findViewById(R.id.total_items_NUMTV);
            TotalItems.setText(String.valueOf(itemsCount));
            popwindow.dismiss();

        });


    }

}
