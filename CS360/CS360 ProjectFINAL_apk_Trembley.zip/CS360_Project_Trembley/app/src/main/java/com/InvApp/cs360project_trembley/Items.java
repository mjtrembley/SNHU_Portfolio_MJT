package com.InvApp.cs360project_trembley;

public class Items {
    int id;
    String name;
    String desc;
    String quantity;
    String alertQuantity;
    String finalAdd;

    public Items() {
        super();
    }

    public Items(int i, String name, String description, String quantity, String alertQuantity) {
        super();
        this.id = i;
        this.name=name;
        this.desc = description;
        this.quantity = quantity;
        this.alertQuantity = alertQuantity;
    }

    // constructor
    public Items(String name, String description, String quantity, String alertQuantity) {
        this.name=name;
        this.desc = description;
        this.quantity = quantity;
        this.alertQuantity = alertQuantity;
    }

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    public String getName(){return name;}
    public void setName(String name){
        this.name=name;
    }

    public String getDesc() {return desc;}
    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getCurrentQuantity() {
        return quantity;
    }
    public void setCurrentQuantity(String qty) {
        this.quantity = qty;
    }

    public String getAlertQuantity() { return alertQuantity;}
    public void setAlertQuantity(String alertQty) {this.alertQuantity = alertQty;}



}
