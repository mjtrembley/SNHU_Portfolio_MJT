package com.InvApp.cs360project_trembley;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class createAccountActivity extends AppCompatActivity {
    Button createAccountButton;
    EditText usernameEdit, passwordEdit, emailEdit, firstnameEdit, lastnameEdit, phoneEdit;
    String usernameHolder, passwordHolder, emailHolder, fNameHolder, lNameHolder, phoneHolder;
    Boolean editTextEmptyHolder;

    SQLiteDatabase sqLiteDatabaseObj;
    String SQLiteDataBaseQueryHolder;
    AccountDB accountDbHelper;
    Cursor cursor;

    String F_Result = "User not found";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        createAccountButton = findViewById(R.id.createAccountButton);

        usernameEdit = findViewById(R.id.usernameEdit);
        passwordEdit = findViewById(R.id.passwordEdit);
        emailEdit = findViewById(R.id.emailEdit);
        firstnameEdit = findViewById(R.id.firstNameEdit);
        lastnameEdit = findViewById(R.id.lastNameEdit);
        phoneEdit = findViewById(R.id.phoneEdit);

        accountDbHelper = new AccountDB(this);

        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Create SQLite DB
                SQLiteDataBaseBuild();

                //Create SQLite table
                SQLiteTableBuild();

                //Check for all fields filled out
                CheckEditTextStatus();

                //Check to see if email already exists or not
                CheckingEmailAlreadyExistsOrNot();

                //Empty all the editText after creating account
                EmptyEditTextAfterCreate();

                Intent intent = new Intent(createAccountActivity.this, loginActivity.class);
                startActivity(intent);
            }
        });
    }
    // SQLite database build method.
    public void SQLiteDataBaseBuild(){
        sqLiteDatabaseObj = openOrCreateDatabase(AccountDB.DATABASE_NAME, Context.MODE_PRIVATE, null);
    }


    // SQLite table build method.
    public void SQLiteTableBuild() {
        sqLiteDatabaseObj.execSQL("CREATE TABLE IF NOT EXISTS " + AccountDB.TABLE_NAME +
                " ( " + AccountDB.Table_Column_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                AccountDB.Table_Column_1_NameF + " VARCHAR, " +
                AccountDB.Table_Column_2_NameL + " VARCHAR, " +
                AccountDB.Table_Column_3_Email + " VARCHAR, " +
                AccountDB.Table_Column_4_Password + " VARCHAR, " +
                AccountDB.Table_Column_5_Number + " VARCHAR, " +
                AccountDB.Table_Column_6_Username + " VARCHAR);");
    }

    // Insert data into SQLite database method.
    public void InsertDataIntoSQLiteDatabase() {
        // If editText is not empty then this block will executed.
        if (editTextEmptyHolder == true) {
            // SQLite query to insert data into table.
            SQLiteDataBaseQueryHolder = "INSERT INTO " + AccountDB.TABLE_NAME + " (firstName, lastName, email, password, phoneNumber, username) " +
                    "VALUES('" + fNameHolder + "', '" + lNameHolder + "', '" + emailHolder + "', '"
                    + passwordHolder + "', '" + phoneHolder + "', '" + usernameHolder + "');";
            // Execute query.
            sqLiteDatabaseObj.execSQL(SQLiteDataBaseQueryHolder);
            // Close SQLite object.
            sqLiteDatabaseObj.close();
            // Print toast after done inserting.
            Toast.makeText(createAccountActivity.this, "Account created successfully!", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(createAccountActivity.this, "Please fill in all fields.", Toast.LENGTH_LONG).show();
        }
    }


    //empties EditText boxes after creation of account
    public void EmptyEditTextAfterCreate(){
        firstnameEdit.getText().clear();
        lastnameEdit.getText().clear();
        usernameEdit.getText().clear();
        passwordEdit.getText().clear();
        phoneEdit.getText().clear();
        emailEdit.getText().clear();
    }

    // Checking Email is already exists or not.
    public void CheckingEmailAlreadyExistsOrNot(){
        // Opening SQLite database write permission.
        sqLiteDatabaseObj = accountDbHelper.getWritableDatabase();
        // Adding search email query to cursor.
        cursor = sqLiteDatabaseObj.query(AccountDB.TABLE_NAME, null, " " + AccountDB.Table_Column_6_Username + "=?",
                new String[]{usernameHolder}, null, null, null);
        while (cursor.moveToNext()) {
            if (cursor.isFirst()) {
                cursor.moveToFirst();
                // If Email is already exists then Result variable value set as Email Found.
                F_Result = "User Found";
                // Closing cursor.
                cursor.close();
            }
        }
        // Calling method to check final result and insert data into SQLite database.
        CheckFinalResult();
    }

    // Checking result
    public void CheckFinalResult(){
        // Checking whether email is already exists or not.
        if(F_Result.equalsIgnoreCase("User Found"))
        {
            // If email is in use, will display toast message
            Toast.makeText(createAccountActivity.this,"User Already Exists",Toast.LENGTH_LONG).show();
        }
        else {
            // If email is not in use, then user details will entered to SQLite database.
            InsertDataIntoSQLiteDatabase();
        }
        F_Result = "User not found" ;
    }


        //method to check fields are filled out
        public void CheckEditTextStatus(){
            usernameHolder = usernameEdit.getText().toString();
            passwordHolder = passwordEdit.getText().toString();
            emailHolder = emailEdit.getText().toString();
            fNameHolder = firstnameEdit.getText().toString();
            lNameHolder = lastnameEdit.getText().toString();
            phoneHolder = phoneEdit.getText().toString();

            if (TextUtils.isEmpty(usernameHolder) || TextUtils.isEmpty(passwordHolder) ||
                TextUtils.isEmpty(emailHolder) || TextUtils.isEmpty(fNameHolder) ||
                TextUtils.isEmpty(lNameHolder) || TextUtils.isEmpty(phoneHolder)){
                editTextEmptyHolder = false;
            } else{
                editTextEmptyHolder = true;
            }
        }




}


