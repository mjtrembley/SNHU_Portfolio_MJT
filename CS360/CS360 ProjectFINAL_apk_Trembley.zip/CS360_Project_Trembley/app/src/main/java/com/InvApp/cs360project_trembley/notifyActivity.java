package com.InvApp.cs360project_trembley;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.activity.result.contract.ActivityResultContract;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;

public class notifyActivity extends AppCompatActivity {
    static String phoneNumberHolder;
    private static final int USER_PERMISSIONS_REQUEST_SEND_SMS = 0;
    private static boolean smsAuthorized = false;
    private static boolean deleteItems = false;
    Switch notifySwitch;
    Button returnButton;
    AlertDialog alertDialog = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notify);
        notifySwitch = findViewById(R.id.notifySwitch);
        returnButton = findViewById(R.id.returnButton);

        // Request sms permission for the device
        String textPermission = Manifest.permission.SEND_SMS;
        // Request sms permission for the device
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.SEND_SMS)) {
                Toast.makeText(this, "Device SMS Permission is Needed", Toast.LENGTH_LONG).show();
            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS},
                        USER_PERMISSIONS_REQUEST_SEND_SMS);
            }
        } else {
            AllowSendSMS();
            Toast.makeText(this, "Device SMS Permission is Allowed", Toast.LENGTH_LONG).show();
        }

    }

    // Receive and evaluate user response from AlertDialog to send SMS
        public static void AllowSendSMS() {
            smsAuthorized = true;
        }

        public static void DenySendSMS() {
            smsAuthorized = false;
        }


        public static void SendText(Context context){
            String phoneNumber = phoneNumberHolder;
            String smsMsg = "You have an item that has reached 0";
            if (smsAuthorized) {
                try {
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage(phoneNumber, null, smsMsg, null, null);
                    Toast.makeText(context, "Text sent", Toast.LENGTH_LONG).show();
                } catch (Exception ex) {
                    Toast.makeText(context, "Device Permission Denied", Toast.LENGTH_LONG).show();
                    ex.printStackTrace();
                }
            } else {
                Toast.makeText(context, "Text alerts Disabled", Toast.LENGTH_LONG).show();
            }
        }
    }
