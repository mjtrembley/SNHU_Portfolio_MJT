package com.InvApp.cs360project_trembley;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class ItemDB extends SQLiteOpenHelper {
    static String DATABASE_NAME = "AccountDatabase";
    public static final String TABLE_NAME = "ItemTable";
    public static final String Table_Column_ID = "id";
    public static final String Table_Column_1_itemName = "itemName";
    public static final String Table_Column_2_Description = "itemDescription";
    public static final String Table_Column_3_Current = "currentQuantity";
    public static final String Table_Column_4_Alert = "alertQuantity";

    public ItemDB(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase database) {
        String CREATE_TABLE = "CREATE TABLE IF NOT EXISTS " + TABLE_NAME + " ( " + Table_Column_ID
                + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + Table_Column_1_itemName + " VARCHAR, "
                + Table_Column_2_Description + " VARCHAR ,"
                + Table_Column_3_Current + " VARCHAR, "
                + Table_Column_4_Alert + " VARCHAR);";
        database.execSQL(CREATE_TABLE);
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        onCreate(db);
    }

    // Add item to database
    public void createItem(Items item) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(Table_Column_1_itemName, item.getName());
        values.put(Table_Column_2_Description, item.getDesc());
        values.put(Table_Column_3_Current, item.getCurrentQuantity());
        values.put(Table_Column_4_Alert, item.getAlertQuantity());

        db.insert(TABLE_NAME, null, values);
        db.close();
    }

    // Read item from Database
    public Items readItem(int id) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_NAME,
                new String[] {Table_Column_ID, Table_Column_1_itemName, Table_Column_2_Description, Table_Column_3_Current, Table_Column_4_Alert}, Table_Column_ID + " = ?",
                new String[] { String.valueOf(id) }, null, null, null, null);

        if (cursor != null)
            cursor.moveToFirst();

        Items item = new Items(Integer.parseInt(Objects.requireNonNull(cursor).getString(0)),
                cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4));

        cursor.close();

        return item;
    }

    // Update item in database
    public int updateItem(Items item) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(Table_Column_1_itemName, item.getName());
        values.put(Table_Column_2_Description, item.getDesc());
        values.put(Table_Column_3_Current, item.getCurrentQuantity());
        values.put(Table_Column_4_Alert, item.getAlertQuantity());

        return db.update(TABLE_NAME, values, Table_Column_ID + " = ?", new String[] { String.valueOf(item.getId()) });
    }

    // Delete item from database
    public void deleteItem(Items item) {
        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(TABLE_NAME, Table_Column_ID + " = ?", new String[] { String.valueOf(item.getId()) });
        db.close();
    }

    // Getting All Items
    public List<Items> getAllItems() {
        List<Items> itemList = new ArrayList<>();

        // Select All Query
        String selectQuery = "SELECT * FROM " + TABLE_NAME;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Items item = new Items();
                item.setId(Integer.parseInt(cursor.getString(0)));
                item.setName(cursor.getString(1));
                item.setDesc(cursor.getString(2));
                item.setCurrentQuantity(cursor.getString(3));
                item.setAlertQuantity(cursor.getString(4));

                itemList.add(item);
            } while (cursor.moveToNext());
        }

        cursor.close();

        return itemList;
    }

    // Deleting all items
    public void deleteAllItems() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME,null,null);
        db.close();
    }

    // Getting Items Count
    public int getItemsCount() {
        String countQuery = "SELECT * FROM " + TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        int itemsTotal = cursor.getCount();
        cursor.close();

        return itemsTotal;
    }
}
