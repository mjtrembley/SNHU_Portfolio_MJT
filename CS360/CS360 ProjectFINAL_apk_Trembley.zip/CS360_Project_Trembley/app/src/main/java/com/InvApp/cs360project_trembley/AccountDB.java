package com.InvApp.cs360project_trembley;

import android.content.Context;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;

public class AccountDB extends SQLiteOpenHelper {
    static String DATABASE_NAME = "AccountDatabase";
    public static final String TABLE_NAME = "UserTable";
    public static final String Table_Column_ID = "id";
    public static final String Table_Column_1_NameF = "firstName";
    public static final String Table_Column_2_NameL = "lastName";
    public static final String Table_Column_3_Email = "email";
    public static final String Table_Column_4_Password = "password";
    public static final String Table_Column_5_Number = "phoneNumber";
    public static final String Table_Column_6_Username = "username";

    public AccountDB(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    //creation of database and table for users.
    @Override
    public void onCreate(SQLiteDatabase database) {
        String CREATE_TABLE = "CREATE TABLE IF NOT EXISTS " + TABLE_NAME + " ( " + Table_Column_ID
                + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + Table_Column_1_NameF + " VARCHAR, "
                + Table_Column_2_NameL + " VARCHAR ,"
                + Table_Column_3_Email + " VARCHAR, "
                + Table_Column_4_Password + " VARCHAR, "
                + Table_Column_5_Number + " VARCHAR, "
                + Table_Column_6_Username + " VARCHAR);";
        database.execSQL(CREATE_TABLE);
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        onCreate(db);
    }
}
