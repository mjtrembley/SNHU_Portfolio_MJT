package com.InvApp.cs360project_trembley;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

public class add_itemActivity extends AppCompatActivity {
    Button addItemButton;
    EditText addItemNameEdit, addItemDescEdit, addCurrQuantityEdit, addAlertQuantityEdit;
    ListView itemListView;
    Boolean editTextEmptyHolder;

    String SQLiteDataBaseQueryHolder;
    String itemHolder, descHolder, currentHolder, alertHolder;
    String F_Result = "Item does not exist" ;
    ItemDB itemHelper;
    SQLiteDatabase sqLiteDatabaseObj;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        addItemNameEdit = findViewById(R.id.addItemNameEdit);
        addItemDescEdit = findViewById(R.id.addItemDescEdit);
        addCurrQuantityEdit = findViewById(R.id.addCurrQuantityEdit);
        addAlertQuantityEdit = findViewById(R.id.addAlertQuantityEdit);
        addItemButton = findViewById(R.id.addItemButton);
        itemListView = findViewById(R.id.itemListView);
        itemHelper = new ItemDB(this);

        addItemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Create SQLite DB
                SQLiteDataBaseBuild();

                //Create SQLite table
                SQLiteTableBuild();

                //Check for all fields filled out
                CheckEditTextStatus();

                //Check for item in database
                CheckingItemExists();

                //Empty all the editText after creating account
                EmptyEditTextAfterCreate();

                Intent intent = new Intent(add_itemActivity.this, homeActivity.class);
                startActivity(intent);
            }
        });
    }

    // SQLite database build method.
    public void SQLiteDataBaseBuild() {
        sqLiteDatabaseObj = openOrCreateDatabase(ItemDB.DATABASE_NAME, Context.MODE_PRIVATE, null);
    }


    // SQLite table build method.
    public void SQLiteTableBuild() {
        sqLiteDatabaseObj.execSQL("CREATE TABLE IF NOT EXISTS " + ItemDB.TABLE_NAME +
                " ( " + ItemDB.Table_Column_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ItemDB.Table_Column_1_itemName + " VARCHAR, " +
                ItemDB.Table_Column_2_Description + " VARCHAR, " +
                ItemDB.Table_Column_3_Current + " VARCHAR, " +
                ItemDB.Table_Column_4_Alert + " VARCHAR);");
    }

    //Method to insert items into the database
    public void InsertItemIntoDatabase() {
        if (editTextEmptyHolder == true) {
            // SQLite query to insert data into table.
            SQLiteDataBaseQueryHolder = "INSERT INTO " + ItemDB.TABLE_NAME + " (itemName, itemDescription, currentQuantity, alertQuantity) " +
                    "VALUES('" + itemHolder + "', '" + descHolder + "', '" + currentHolder + "', '" + alertHolder + "');";
            // Execute query.
            sqLiteDatabaseObj.execSQL(SQLiteDataBaseQueryHolder);
            // Close SQLite object.
            sqLiteDatabaseObj.close();
            // Print toast after done inserting.
            Toast.makeText(add_itemActivity.this, "Item has been added to inventory.", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(add_itemActivity.this, "Please fill in all fields.", Toast.LENGTH_LONG).show();

        }
    }

    //empties EditText boxes after creation of item
    //so there is no text the next time user goes to create a new item
    public void EmptyEditTextAfterCreate() {
        addItemNameEdit.getText().clear();
        addItemDescEdit.getText().clear();
        addCurrQuantityEdit.getText().clear();
        addAlertQuantityEdit.getText().clear();
    }

    //Method to check to make sure all fields are filled in
    public void CheckEditTextStatus(){
        itemHolder = addItemNameEdit.getText().toString();
        descHolder = addItemDescEdit.getText().toString();
        currentHolder = addCurrQuantityEdit.getText().toString();
        alertHolder = addAlertQuantityEdit.getText().toString();


        if (TextUtils.isEmpty(itemHolder) || TextUtils.isEmpty(descHolder) ||
                TextUtils.isEmpty(currentHolder) || TextUtils.isEmpty(alertHolder)){
            editTextEmptyHolder = false;
        } else{
            editTextEmptyHolder = true;
        }

    }

    // Checking if item already exists or not.
    public void CheckingItemExists(){
        // Opening SQLite database write permission.
        sqLiteDatabaseObj = itemHelper.getWritableDatabase();
        // Adding search email query to cursor.
        Cursor cursor = sqLiteDatabaseObj.query(ItemDB.TABLE_NAME, null, " " + ItemDB.Table_Column_1_itemName + "=?",
                new String[]{itemHolder}, null, null, null);
        while (cursor.moveToNext()) {
            if (cursor.isFirst()) {
                cursor.moveToFirst();
                F_Result = "Item exists";
                // Closing cursor.
                cursor.close();
            }
        }
        // Calling method to check final result and insert data into SQLite database.
        CheckFinalResult();
    }
    public void CheckFinalResult(){
        // Checking whether item already exists or not.
        if(F_Result.equalsIgnoreCase("Item exists"))
        {
            // If item exists, will display toast message
            Toast.makeText(add_itemActivity.this,"Item already exists!",Toast.LENGTH_LONG).show();
        }
        else {
            // If item does not exist, will be entered into database.
            InsertItemIntoDatabase();
        }
        F_Result = "Item does not exist" ;
    }

}