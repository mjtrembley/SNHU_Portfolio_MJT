package com.InvApp.cs360project_trembley;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class loginActivity extends AppCompatActivity {

    Button loginButton, newAccountButton;
    EditText username, password;
    AccountDB sqLiteHelper;
    Boolean editTextEmptyHolder;
    SQLiteDatabase sqLiteDatabaseObj;
    Cursor cursor;
    String usernameHolder, passwordHolder;
    String TempPassword = "Not_found";
    public static final String usernameBlank = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        loginButton = (Button) findViewById(R.id.loginButton);
        newAccountButton = (Button) findViewById(R.id.newUserButton);
        username = (EditText) findViewById(R.id.usernameLogin);
        password = (EditText) findViewById(R.id.passwordLogin);

        sqLiteHelper = new AccountDB(this);



    loginButton.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            //check to make sure fields are filled
            CheckEditTextStatus();
            //login method
            Login();
        }
    });

    newAccountButton.setOnClickListener(new View.OnClickListener(){
        @Override
        public void onClick(View view){
            Intent intent = new Intent(loginActivity.this, createAccountActivity.class);
            startActivity(intent);
        }
    });

    }

    @SuppressLint("Range")
    public void Login(){
        if(editTextEmptyHolder) {
            // Opening SQLite database write permission.
            sqLiteDatabaseObj = sqLiteHelper.getWritableDatabase();
            // Adding search user query to cursor.
            cursor = sqLiteDatabaseObj.query(AccountDB.TABLE_NAME, null, " " + AccountDB.Table_Column_6_Username + "=?",
                    new String[]{usernameHolder}, null, null, null);
            while (cursor.moveToNext()) {
                if (cursor.isFirst()) {
                    cursor.moveToFirst();
                    // Storing Password associated with entered email.
                    TempPassword = cursor.getString(cursor.getColumnIndex(AccountDB.Table_Column_4_Password));
                    // Closing cursor.
                    cursor.close();
                }
            }
            //method to check result
            CheckFinalResult();
        }
        else {
            //If any of login EditText empty then this block will be executed.
            Toast.makeText(loginActivity.this,"Please Enter username and/or password.",Toast.LENGTH_LONG).show();
        }
    }

    // Checking EditText is empty or not.
    public void CheckEditTextStatus(){
        // Getting value from All EditText and storing into String Variables.
        usernameHolder = username.getText().toString();
        passwordHolder = password.getText().toString();
        // Checking EditText is empty or no using TextUtils.
        if( TextUtils.isEmpty(usernameHolder) || TextUtils.isEmpty(passwordHolder)){
            editTextEmptyHolder = false ;
        }
        else {
            editTextEmptyHolder = true ;
        }
    }


    public void CheckFinalResult(){
        if(TempPassword.equalsIgnoreCase(passwordHolder))
        {
            Toast.makeText(loginActivity.this,"Login Successful",Toast.LENGTH_LONG).show();
            // Going to Dashboard activity after login success message.
            Intent intent = new Intent(loginActivity.this, homeActivity.class);
            startActivity(intent);
        }
        else {
            Toast.makeText(loginActivity.this,"Username or Password not found. Please try again.",Toast.LENGTH_LONG).show();
        }
        TempPassword = "NOT_FOUND" ;
    }

}

