package com.InvApp.cs360project_trembley;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class homeActivity extends AppCompatActivity {
    ListView itemList;
    TextView totalItems;
    ImageButton notifyButton;
    ItemDB db;
    ArrayList<Items> items;
    listGenerate customList;
    android.app.AlertDialog alertDialog = null;
    private static final int USER_PERMISSIONS_REQUEST_SEND_SMS = 0;
    int itemsCounter;
    static Boolean smsAuthorized;
    static String phoneNumberHolder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        itemList= findViewById(R.id.itemListView);
        totalItems = findViewById(R.id.total_items_NUMTV);
        notifyButton = findViewById(R.id.allowNotify);
        db = new ItemDB(this);
        smsAuthorized = false;

        items = (ArrayList<Items>) db.getAllItems();
        itemsCounter = db.getItemsCount();


        if (itemsCounter > 0){
            customList = new listGenerate(this,items,db);
            itemList.setAdapter(customList);
        } else {
            Toast.makeText(this, "Nothing in inventory!", Toast.LENGTH_LONG).show();
        }
        totalItems.setText(String.valueOf(itemsCounter));

        notifyButton.setOnClickListener(view -> {
            // Request sms permission for the device
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {

                if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {
                    Toast.makeText(this,"Device SMS Permission is Needed", Toast.LENGTH_LONG).show();
                } else {
                    ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.SEND_SMS},
                            1);
                }
            } else {
                Toast.makeText(this,"Device SMS Permission is Allowed", Toast.LENGTH_LONG).show();
            }

            // Open SMS Alert Dialog
            alertDialog = smsNotify.doubleButton(this);
            alertDialog.show();
        });
    }

    // Receive and evaluate user response from AlertDialog to send SMS
    public static void AllowSendSMS() {
        smsAuthorized = true;

    }

    public static void DenySendSMS() {
        smsAuthorized = false;
    }


    public static void SendText(Context context){
        String phoneNumber = "+1-555-521-5554";
        String smsMsg = "You have an item that has reached 0";
        if (smsAuthorized) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNumber, null, smsMsg, null, null);
                Toast.makeText(context, "Text sent", Toast.LENGTH_LONG).show();
            } catch (Exception ex) {
                Toast.makeText(context, "Device Permission Denied", Toast.LENGTH_LONG).show();
                ex.printStackTrace();
            }
        } else {
            Toast.makeText(context, "Text alerts Disabled", Toast.LENGTH_LONG).show();
        }
    }

    public void onAddItemClick(View view) {
        Intent intent = new Intent(this, add_itemActivity.class);
        startActivity(intent);
    }
}