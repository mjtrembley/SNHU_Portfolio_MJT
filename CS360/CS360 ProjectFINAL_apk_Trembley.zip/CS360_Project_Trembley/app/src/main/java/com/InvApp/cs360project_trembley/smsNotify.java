package com.InvApp.cs360project_trembley;

import android.app.AlertDialog;
import android.widget.Toast;

public class smsNotify {
    public static AlertDialog doubleButton(final homeActivity context){
        // Use the Builder class for convenient dialog construction
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(R.string.sms_button_ltitle)
                .setIcon(R.drawable.notification)
                .setCancelable(false)
                .setMessage(R.string.sms_message)
                .setPositiveButton(R.string.sms_enable, (dialog, arg1) -> {
                    Toast.makeText(context, "Text Alerts Enabled", Toast.LENGTH_LONG).show();
                    homeActivity.AllowSendSMS();
                    dialog.cancel();
                })
                .setNegativeButton(R.string.sms_disable, (dialog, arg1) -> {
                    Toast.makeText(context, "Text Alerts Disabled", Toast.LENGTH_LONG).show();
                    homeActivity.DenySendSMS();
                    dialog.cancel();
                });

        // Create the AlertDialog object and return it
        return builder.create();
    }
}
