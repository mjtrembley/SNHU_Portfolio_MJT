#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

void SortVector(vector<int>& myVec){ //function to sort vector in ascending order
   unsigned int i;
    
    std::sort(myVec.begin(), myVec.end());
    
    for (i = 0; i < myVec.size(); ++i){  //loop to iterate through vector and output
        cout << myVec.at(i) << " ";
        
  }
    
}
int main() {
   vector<int> myVec;
   unsigned int i;
   int userValue;
   
   
   for (i = 0; i < myVec.size(); ++i){
      cin >> userValue;
      userValue = myVec.at(i);

   }
   SortVector(myVec);
   
   
   return 0;
}
