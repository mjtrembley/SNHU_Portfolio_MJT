#ifndef ContactNode
#include <string>

using namespace std;

class ContactNode{
public:
   ContactNode(); //default constructor
   ContactNode(string name, string phone); //constructor w/ parameters
   void InsertAfter(ContactNode*); //function to insert data into linked list
   string GetName();
   string GetPhoneNumber();
   ContactNode* GetNext();
   void PrintContactNode();

private:
   string contactName;
   string contactPhoneNum;
   ContactNode* nextNodePtr;


};

#endif