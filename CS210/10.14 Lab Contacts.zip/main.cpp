#include <iostream>
#include "ContactNode.h"
using namespace std;

int main() {
//variables and linked list declaration
ContactNode *List;
string name;
string phoneNum;

List = new ContactNode; // linked list creation
   for (int i = 0; i < 3; i++){
      cout << "Person " <<i+1<< endl;
      cout << "Enter name:"<< endl;
      getline(cin, name);
      
      cout << "Enter phone number:"<< endl;
      getline(cin, phoneNum);
      
      cout << "You entered: " << name<< ", " << phoneNum <<"\n" << endl;
      //where function is called to store data in linked list
      List->InsertAfter(new ContactNode(name,phoneNum)); 
}
   cout << "CONTACT LIST" <<endl;
      //call to function to print contact linked list
      List->PrintContactNode();
   return 0;
}
