#include <iostream>
#include <iomanip>
#ifndef Investment
using namespace std;
class Investment {
public:
	//Data variables needed here for this class
	double initialDeposit = 0.0;
	double interestRate = 0.0;
	double monthlyDeposit = 0.0;
	double years = 0.0;

public:
	//Constructor here
	Investment() {}
	//Class functions below
	void setInitialDeposit(double fromUserInput);
	double getInitialDeposit();
	void setInterestRate(double fromUserInput);
	double getInterestRate();
	void setMonthlyDeposit(double fromUserInput);
	double getMonthlyDeposit();
	void setNumYears(double fromUserInput);
	double getNumYears();
	double interestEarned(double initialDeposit, double interestRate);
	void grandTotal(double interestEarned, double initialDeposit, double years);
	void grandTotalMonthly(double interestEarned, double monthlyDeposit, double intiialDeposit, double interestRate, double years);
};

#endif