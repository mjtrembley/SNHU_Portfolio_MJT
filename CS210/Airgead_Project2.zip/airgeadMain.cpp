#include <iostream>
#include <iomanip>
#include "Investment.h"

using namespace std;

	int main() {
		//Declare variables for input
		double initialDeposit, monthlyDeposit, interestRate, years, months;

		//Declare variables for data
		double totalInterestEarned;

		Investment userInput;
		//Display menu to the user
		cout << "**********************************" << endl;
		cout << "*********** Data Input ***********" << endl;
		cout << "Initial Investment Amount: " << endl;
		cout << "Monthly Deposit: " << endl;
		cout << "Annual Interest: " << endl;
		cout << "Number of years: " << "\n" << endl;


		//Get user input
		cout << "**********************************" << endl;
		cout << "*********** Data Input ***********" << endl;
		cout << "Initial Investment Amount: $" << endl;
		cin >> initialDeposit;
		userInput.setInitialDeposit(initialDeposit);
		cout << "Monthly Deposit: $" << endl;
		cin >> monthlyDeposit;
		userInput.setMonthlyDeposit(monthlyDeposit);
		cout << "Annual Interest: %" << endl;
		cin >> interestRate;
		userInput.setInterestRate(interestRate);
		cout << "Number of years: " << endl;
		cin >> years;
		userInput.setNumYears(years);
		months = years * 12;

		totalInterestEarned = userInput.interestEarned(initialDeposit, interestRate);




		//Display year end data if no monthly deposits

		cout << endl << "Balance and Interest Without Additional Monthly Deposits" << endl;
		cout << "================================================================" << endl;
		cout << "Year          Year End Balance          Year End Earned Interest" << endl;
		cout << "----------------------------------------------------------------" << endl;
		userInput.grandTotal(totalInterestEarned, initialDeposit, years);


		//Display year end data with monthly deposits
		cout << endl << "Balance and Interest With Additional Monthly Deposits" << endl;
		cout << "================================================================" << endl;
		cout << "Year          Year End Balance          Year End Earned Interest" << endl;
		cout << "----------------------------------------------------------------" << endl;
		userInput.grandTotalMonthly(totalInterestEarned, monthlyDeposit, initialDeposit, interestRate, years);


		return 0;
	}