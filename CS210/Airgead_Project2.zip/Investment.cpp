#include <iostream>
#include "Investment.h"
using namespace std;

//function defintions in this .cpp file
void Investment::setInitialDeposit(double fromUserInput) { initialDeposit = fromUserInput; }
double Investment:: getInitialDeposit() { return initialDeposit; }
void Investment::setInterestRate(double fromUserInput) { interestRate = fromUserInput; }
double Investment:: getInterestRate() { return interestRate; }
void Investment::setMonthlyDeposit(double fromUserInput) { monthlyDeposit = fromUserInput; }
double Investment:: getMonthlyDeposit() { return monthlyDeposit; }
void Investment::setNumYears(double fromUserInput) { years = fromUserInput; }
double Investment:: getNumYears() { return years; }

double Investment::interestEarned(double initialDeposit, double interestRate) {
	double totInterest = (initialDeposit + (interestRate / 100.0));
	return totInterest;
}
	void Investment::grandTotal(double interestEarned, double initialDeposit, double years) {
	//Calculate yearly interest and year end total
		for (int i = 0; i < years; i++) {
			//Calculate yearly interest amount
			interestEarned = ((initialDeposit) * (interestRate / 100));
			double interestEarnedSum = (i + 1) * interestEarned;
			//Calculate year end total
			double totalAmount = initialDeposit + interestEarnedSum;

			//Show decimal as dollar amount correctly with set precision to 2 decimal places
			cout << (i + 1) << "\t\t$" << fixed << setprecision(2) << totalAmount << "\t\t\t$" << interestEarnedSum << endl;
		}
	}
void Investment::grandTotalMonthly(double interestEarned, double monthlyDeposit, double intiialDeposit, double interestRate, double years) {
	for (int i = 0; i < years; i++) {
		//Declare variables for function
		double yearlyTotalInterest = 0.0;
		double totalAmount = initialDeposit;

		for (int j = 0; j < 12; j++) {
			//Calculate monthly interest amount
			interestEarned = (((totalAmount + monthlyDeposit) * (interestRate / 100.0)) / 12.0);
			
			double interestEarnedSum = (i + 1) * interestEarned;

			//total annual interest earned
			yearlyTotalInterest = yearlyTotalInterest + interestEarnedSum;

			//Calculate total
			totalAmount = totalAmount + monthlyDeposit + interestEarnedSum;
			
		}
		//Show decimal as dollar amount correctly with set precision to 2 decimal places
		cout << (i + 1) << "\t\t$" << fixed << setprecision(2) << totalAmount << "\t\t\t$" << yearlyTotalInterest << endl;
	}
}