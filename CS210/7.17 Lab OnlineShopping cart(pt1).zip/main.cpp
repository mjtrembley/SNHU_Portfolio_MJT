#include <iostream>
using namespace std;

#include "ItemToPurchase.h"

int main() {
   ItemToPurchase item1, item2;
   string itemName;
   int itemPrice;
   int itemQuantity;
   int totalCost = 0;

   cout << "Item 1" << endl;
   cout << "Enter the item name:" << endl;
   getline(cin,itemName);
   cout << "Enter the item price:" << endl;
   cin >> itemPrice; 
   cout << "Enter the item quantity:" << "\n" << endl;
   cin >> itemQuantity;
   
   item1.SetName(itemName);
   item1.SetPrice(itemPrice);
   item1.SetQuantity(itemQuantity);
   
   cin.ignore();
   
   cout << "Item 2" << endl;
   cout << "Enter the item name:" << endl;
   getline(cin,itemName);
   cout << "Enter the item price:" << endl;
   cin >> itemPrice; 
   cout << "Enter the item quantity:" << "\n" << endl;
   cin >> itemQuantity;
   
   item2.SetName(itemName);
   item2.SetPrice(itemPrice);
   item2.SetQuantity(itemQuantity);
   
   cout << "TOTAL COST"<< endl;
   cout << item1.GetName() << " " << item1.GetQuantity() << " @ $" << item1.GetPrice() << " = $" <<
   item1.GetQuantity() * item1.GetPrice() << endl;
   
   cout << item2.GetName() << " " << item2.GetQuantity() << " @ $" << item2.GetPrice() << " = $" <<
   item2.GetQuantity() * item2.GetPrice() <<  "\n" << endl;
   
   totalCost = (item1.GetQuantity() * item1.GetPrice()) + (item2.GetQuantity() * item2.GetPrice());
   cout << "Total: $" << totalCost << endl;   
   
   
   
   return 0;
}