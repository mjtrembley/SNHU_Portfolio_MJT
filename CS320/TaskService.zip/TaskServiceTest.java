import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TaskServiceTest {
	private String taskId, taskNameTest, taskDescriptionTest, tooLongID, tooLongName, 
	tooLongDescription; 
	
	@BeforeEach
	void setUp() throws Exception {
		taskId = "08032019";
		taskNameTest = "Email Admin";
		taskDescriptionTest = "Send daily email reports to administrative team";
		tooLongID = "August 3, 2019";
		tooLongName = "Email Administrative team";
		tooLongDescription = "Send daily email reports to administrative team and inform them of any roadblocks for tomorrows huddle";
	}

	@Test
	void testAddNewTask() {
		TaskService task = new TaskService();
		task.addNewTask();
		assertAll(
				() -> assertNotNull(task.seeList().get(0).getTaskId()),
				() -> assertEquals("empty",
						task.seeList().get(0).getTaskName()),
				() -> assertEquals("empty",
						task.seeList().get(0).getDescription()));
		task.addNewTask(taskNameTest);
		assertAll(
				() -> assertNotNull(task.seeList().get(1).getTaskId()),
				() -> assertEquals("Email Admin",
						task.seeList().get(1).getTaskName()),
				() -> assertEquals("empty",
						task.seeList().get(1).getDescription()));
		task.addNewTask(taskNameTest, taskDescriptionTest);
		assertAll(
				() -> assertNotNull(task.seeList().get(2).getTaskId()),
				() -> assertEquals("Email Admin",
						task.seeList().get(2).getTaskName()),
				() -> assertEquals("Send daily email reports to administrative team",
						task.seeList().get(2).getDescription()));	
	}

	@Test
	void testDeleteTask() {
		TaskService task = new TaskService();
	    task.addNewTask();
	    assertThrows(Exception.class, () -> task.deleteTask(taskId));
	    assertAll(
	    		()-> task.deleteTask(task.seeList().get(0).getTaskId()));
	}

	@Test
	void testUpdateTaskName() throws Exception {
		TaskService task = new TaskService();
	    task.addNewTask();
	    task.updateTaskName(task.seeList().get(0).getTaskId(),taskNameTest);
	    assertEquals(taskNameTest, task.seeList().get(0).getTaskName());
	    assertThrows(IllegalArgumentException.class,
	    		()-> task.updateTaskName(task.seeList().get(0).getTaskId(),tooLongName));
	    assertThrows(IllegalArgumentException.class,
	            ()-> task.updateTaskName(task.seeList().get(0).getTaskId(), null));
	    assertThrows(Exception.class,
	    		()-> task.updateTaskName(taskId, taskNameTest));
	}

	@Test
	void testUpdateDescription() throws Exception {
		TaskService task = new TaskService();
		task.addNewTask();
		task.updateDescription(task.seeList().get(0).getTaskId(),taskDescriptionTest);
		assertEquals(taskDescriptionTest, task.seeList().get(0).getDescription());
		assertThrows(IllegalArgumentException.class,
				()->task.updateDescription(task.seeList().get(0).getTaskId(),tooLongDescription));
		assertThrows(IllegalArgumentException.class,
				()-> task.updateDescription(task.seeList().get(0).getTaskId(), null));
		assertThrows(Exception.class,
				()-> task.updateDescription(taskId, taskDescriptionTest));
	}

}
