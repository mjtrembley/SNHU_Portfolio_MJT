
public class Task {

	private String uniqueTaskId;
	private String taskName;
	private String taskDescription;
	private String empty = "empty";
	
Task(){
	this.uniqueTaskId = empty;
	this.taskName = empty;
	this.taskDescription = empty;
}

public String getTaskId() {return uniqueTaskId;}
public String getTaskName() {return taskName;}
public String getDescription() {return taskDescription;}

Task(String uniqueTaskId){
	updateTaskId(uniqueTaskId);
	this.taskName = empty;
	this.taskDescription = empty;
}
Task(String uniqueTaskId, String taskName){
	updateTaskId(uniqueTaskId);
	updateTaskName(taskName);
	this.taskDescription = empty;
}
Task(String uniqueTaskId, String taskName, String taskDescription){
	updateTaskId(uniqueTaskId);
	updateTaskName(taskName);
	updateDescription(taskDescription);
}

public void updateTaskId(String uniqueTaskId){
	if (uniqueTaskId == null) {
		throw new IllegalArgumentException("Task ID cannot be null/empty");
	} else if (uniqueTaskId.length() > 10) {
		throw new IllegalArgumentException("Task ID cannot be longer than 10 characters");
	} else {	
		this.uniqueTaskId = uniqueTaskId;
	}
  }

public void updateTaskName(String taskName){
	if (taskName == null) {
		throw new IllegalArgumentException("Task ID cannot be null/empty");
	} else if (taskName.length() > 20 ) {
		throw new IllegalArgumentException("Task Name cannot be longer than 20 characters");	
	} else {
		this.taskName = taskName;
	}
}

public void updateDescription(String taskDescription) {
	if (taskDescription == null) {
		throw new IllegalArgumentException("Task Description cannot be null/empty");
	} else if (taskDescription.length() > 50 ) {
		throw new IllegalArgumentException("Task Description cannot be longer than 50 characters");	
	} else {
		this.taskDescription = taskDescription;
	}
 }

}
