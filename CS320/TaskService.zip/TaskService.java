import java.util.List;
import java.util.ArrayList;
import java.util.UUID;

public class TaskService {

	private UUID id;
	private String uniqueTaskId;
	private List<Task> taskList = new ArrayList<Task>();

	{
		id = UUID.randomUUID();
		uniqueTaskId = id.toString().substring(0, 10);
	}
private String newTaskId() {
	return uniqueTaskId;
}
private Task taskSearch(String uniqueTaskId) throws Exception {
    int i = 0;
    while (i < taskList.size()) {
      if (uniqueTaskId.equals(taskList.get(i).getTaskId())) {
        return taskList.get(i);
      } i++;
    }
    throw new Exception("The task could not be found.");
  }

public List<Task> seeList(){return taskList;}

public void addNewTask() { 
	Task task = new Task(newTaskId());
	taskList.add(task);
}
public void addNewTask(String taskName) {
	 Task task = new Task(newTaskId(), taskName);
	 taskList.add(task);
	 }
public void addNewTask(String taskName, String taskDescription) {
	Task task = new Task(newTaskId(), taskName, taskDescription);
		taskList.add(task);
	}
public void deleteTask(String uniqueTaskId) throws Exception {
	taskList.remove(taskSearch(uniqueTaskId));
}
public void updateTaskName(String uniqueTaskId, String taskName) throws Exception {
	 taskSearch(uniqueTaskId).updateTaskName(taskName);
}
public void updateDescription(String uniqueTaskId, String taskDescription) throws Exception{
	taskSearch(uniqueTaskId).updateDescription(taskDescription);
}
}
