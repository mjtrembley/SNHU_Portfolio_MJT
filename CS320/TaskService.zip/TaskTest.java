import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TaskTest {
	private String taskId, taskNameTest, taskDescriptionTest, tooLongID, tooLongName, 
	tooLongDescription; 

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
		taskId = "08032019";
		taskNameTest = "Email Admin";
		taskDescriptionTest = "Send daily email reports to administrative team";
		tooLongID = "August 3, 2019";
		tooLongName = "Email Administrative team";
		tooLongDescription = "Send daily email reports to administrative team and inform them of any roadblocks for tomorrows huddle";
	}

	@AfterEach
	void tearDown() throws Exception {
	}


	@Test
	void testGetTaskId() {
		assertNotNull(taskId);
		int length = String.valueOf(taskId).length();
		assertTrue(length < 10);
		int tooLong = String.valueOf(tooLongID).length();
		assertTrue(tooLong > 10);
	}

	@Test
	void testGetTaskName() {
		assertNotNull(taskNameTest);
		int length = String.valueOf(taskNameTest).length();
		assertTrue(length < 20);
		int tooLong = String.valueOf(tooLongName).length();
		assertTrue(tooLong > 20);
	}

	@Test
	void testGetDescription() {
		assertNotNull(taskDescriptionTest);
		int length = String.valueOf(taskDescriptionTest).length();
		assertTrue(length < 50);
		int tooLong = String.valueOf(tooLongDescription).length();
		assertTrue(tooLong > 50);
	}

	@Test
	void testUpdateTaskId() {
		Task task = new Task();
		task.updateTaskId(taskId);
		assertNotNull(taskId);
		assertNotEquals(taskId, "empty");
		assertAll(
		() -> assertEquals(taskId, task.getTaskId()),
		() -> assertThrows(IllegalArgumentException.class,
				() -> task.updateTaskId(null)),
		() -> assertThrows(IllegalArgumentException.class,
				() -> task.updateTaskId(tooLongID)));
		
	}

	@Test
	void testUpdateTaskName() {
		Task task = new Task();
		task.updateTaskName(taskNameTest);
		assertNotNull(taskNameTest);
		assertNotEquals(taskNameTest, "empty");
		assertAll(
		() -> assertEquals(taskNameTest, task.getTaskName()),
		() -> assertThrows(IllegalArgumentException.class,
				() -> task.updateTaskName(null)),
		() -> assertThrows(IllegalArgumentException.class,
				() -> task.updateTaskName(tooLongName)));
	}

	@Test
	void testUpdateDescription() {
		Task task = new Task();
		task.updateDescription(taskDescriptionTest);
		assertNotNull(taskDescriptionTest);
		assertNotEquals(taskDescriptionTest, "empty");
		assertAll(
		() -> assertEquals(taskDescriptionTest, task.getDescription()),
		() -> assertThrows(IllegalArgumentException.class,
				() -> task.updateDescription(null)),
		() -> assertThrows(IllegalArgumentException.class,
				() -> task.updateDescription(tooLongDescription)));
	}

}
