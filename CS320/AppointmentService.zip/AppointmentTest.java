import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AppointmentTest {
	  private String apptID;
	  private String apptDescription;
	  private String tooLongId;
	  private String tooLongDescription;
	  private Date date, pastDate;

	@SuppressWarnings("deprecation")
	@BeforeEach
	void setUp() throws Exception {
		  apptID = "1234567890";
		  apptDescription = "This is the required appointment description";
		  date = new Date(3022, Calendar.NOVEMBER, 7);
		  tooLongId = "123456789123456789";
		  tooLongDescription ="This description is maybe, hopefully, possibly, more than 50 characters long";
		  pastDate = new Date(0);
	}

	 @Test
	  void testUpdateAppointmentId() {
	    Appointment appt = new Appointment();
	    assertThrows(IllegalArgumentException.class,
	             () -> appt.updateApptId(null));
	    assertThrows(IllegalArgumentException.class,
	             () -> appt.updateApptId(tooLongId));
	    appt.updateApptId(apptID);
	    assertEquals(apptID, appt.getApptId());
	  }
	
	  @Test
	  void testUpdateDate() {
	    Appointment appt = new Appointment();
	    assertThrows(IllegalArgumentException.class, 
	    		() -> appt.updateDate(null));
	    assertThrows(IllegalArgumentException.class,
	            () -> appt.updateDate(pastDate));
	    appt.updateDate(date);
	    assertEquals(date, appt.getDate());
	  }
	

	  @Test
	  void testUpdateDescription() {
	    Appointment appt = new Appointment();
	    assertThrows(IllegalArgumentException.class,
	             () -> appt.updateDescription(null));
	    assertThrows(IllegalArgumentException.class,
	             () -> appt.updateDescription(tooLongDescription));
	    appt.updateDescription(apptDescription);
	    assertEquals(apptDescription, appt.getApptDescription());
	  }
	  
	  @Test
	  void testGetAppointmentId() {
		Appointment appt = new Appointment(apptID);
		assertNotNull(appt.getApptId());
		assertEquals(appt.getApptId().length(), 10);
		assertEquals(apptID, appt.getApptId());
		  }
	  @Test
	  void testGetAppointmentDate() {
	    Appointment appt = new Appointment(apptID, date);
	    assertNotNull(appt.getDate());
	    assertEquals(date, appt.getDate());
	  }
	  @Test
	  void testGetDescription() {
	    Appointment appt = new Appointment(apptID, date, apptDescription);
	    assertNotNull(appt.getApptDescription());
	    assertTrue(appt.getApptDescription().length() <= 50);
	    assertEquals(apptDescription, appt.getApptDescription());
	  }
	  
}
