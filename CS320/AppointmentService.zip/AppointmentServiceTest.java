import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AppointmentServiceTest {
	  private String apptID;
	  private String apptDescription;
	  private String tooLongId;
	  private String tooLongDescription;
	  private Date date, pastDate;
	  
	  
	@SuppressWarnings("deprecation")
	@BeforeEach
	void setUp() throws Exception {
		apptID = "1234567890";
		apptDescription = "This is the required appointment description";
		date = new Date(3022, Calendar.NOVEMBER, 7);
		tooLongId = "123456789123456789";
		tooLongDescription ="This description is maybe, hopefully, possibly, more than 50 characters long";
		pastDate = new Date(0);
	}

	@Test
	void testAddNewAppt() {
		  AppointmentService service = new AppointmentService();

		    service.addNewAppt();
		    assertNotNull(service.seeApptList().get(0).getApptId());
		    assertNotNull(service.seeApptList().get(0).getDate());
		    assertNotNull(service.seeApptList().get(0).getApptDescription());

		    service.addNewAppt(date);
		    assertNotNull(service.seeApptList().get(1).getApptId());
		    assertEquals(date,service.seeApptList().get(1).getDate());
		    assertNotNull(service.seeApptList().get(1).getApptDescription());

		    service.addNewAppt(date, apptDescription);
		    assertNotNull(service.seeApptList().get(2).getApptId());
		    assertEquals(date,service.seeApptList().get(2).getDate());
		    assertEquals(apptDescription, service.seeApptList().get(2).getApptDescription());

		    assertThrows(IllegalArgumentException.class,
		                 () -> service.addNewAppt(pastDate));
		    assertThrows(IllegalArgumentException.class,
		                 () -> service.addNewAppt(date, tooLongDescription));
		  }

	@Test
	void testDeleteAppointment() throws Exception {
		 AppointmentService service = new AppointmentService();
		 	service.addNewAppt();
		 	assertThrows(Exception.class,
		 			() -> service.deleteAppointment(apptID));
		 	assertAll(
		 			()->service.deleteAppointment(service.seeApptList().get(0).getApptId()));
		   
	}

}
