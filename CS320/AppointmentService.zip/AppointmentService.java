import java.util.List;
import java.util.ArrayList;
import java.util.Date;
import java.util.UUID;


public class AppointmentService {

	private UUID id;
	private String uniqueApptId;
	private List<Appointment> appointmentList = new ArrayList<Appointment>();
	
	private List<Appointment> randomID = new ArrayList<Appointment>();
	{
		id = UUID.randomUUID();
		uniqueApptId = id.toString().substring(0, 10);
	}
	
private String newApptId() {return uniqueApptId;}
public List<Appointment> seeApptList(){return appointmentList;}

private Appointment apptSearch(String uniqueApptId) throws Exception {
    int i = 0;
    int j = i + 1;
    while (i < appointmentList.size()) {
      if (uniqueApptId.equals(appointmentList.get(i).getApptId())) {
        return appointmentList.get(i);
      } i++;
      if (appointmentList.get(i).getApptId() == appointmentList.get(j).getApptId()) {
    	  throw new Exception("Duplicate Found!");
      } i++;
    }
    throw new Exception("The appointment could not be found.");
  }

public void addNewAppt() { 
	Appointment appt = new Appointment(newApptId());
	appointmentList.add(appt);
}

public void addNewAppt(Date date) {
    Appointment appt = new Appointment(newApptId(), date);
    appointmentList.add(appt);
  }
public void addNewAppt(Date date, String apptDescription) {
    Appointment appt = new Appointment(newApptId(), date, apptDescription);
    appointmentList.add(appt);
  }
public void deleteAppointment(String uniqueApptId) throws Exception {
    appointmentList.remove(apptSearch(uniqueApptId));
  }

}
