import java.util.Date;

public class Appointment {
	
	private String uniqueApptId;
	private Date apptDate;
	private String apptDescription;
	private String empty = "empty";
	
	
Appointment(){
	this.uniqueApptId = empty;
	this.apptDescription = empty;
	Date currentDate = new Date();
	apptDate = currentDate;
}

public String getApptId() { return uniqueApptId;}
public Date getDate() { return apptDate;}
public String getApptDescription() {return apptDescription;}

Appointment(String uniqueApptId){
	Date currentDate = new Date();
	updateApptId(uniqueApptId);
	apptDate = currentDate;
	this.apptDescription = empty;
}
Appointment(String uniqueApptId, Date date){
	updateApptId(uniqueApptId);
	updateDate(date);
	this.apptDescription = empty;
}
Appointment(String uniqueApptId, Date date, String apptDescription){
	updateApptId(uniqueApptId);
	updateDate(date);
	updateDescription(apptDescription);
}
public void updateApptId(String uniqueApptId) {
	if (uniqueApptId == null) {
		throw new IllegalArgumentException("Appointment ID cannot be null/empty");
	} else if (uniqueApptId.length() > 10) {
		throw new IllegalArgumentException("Appointment ID cannot be longer than 10 characters");
	} else {	
		this.uniqueApptId = uniqueApptId;
	}
	
}

public void updateDate(Date date) {
	if (date == null) {
		throw new IllegalArgumentException("Appointment date cannot be null/empty");
	} else if (date.before(new Date())) {
		throw new IllegalArgumentException("Cannot make appointment in the past.");
	} else {
	this.apptDate = date;
	}
}
	
public void updateDescription(String apptDescription) {
	if (apptDescription == null) {
		throw new IllegalArgumentException("Appointment Description cannot be null/empty");
	} else if (apptDescription.length() > 50 ) {
		throw new IllegalArgumentException("Appointment Description cannot be longer than 50 characters");	
	} else {
		this.apptDescription = apptDescription;
	}
}

















}
