import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ContactTest {

	private String contactId, firstNameTest, lastNameTest, NumberTest, AddressTest, tooLongContact, tooLongFirstName, 
	tooLongLastName, tooLongNumber, tooShortNumber, tooLongAddress; //establish each variable to use
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception { //create values for each variable for testing
		contactId = "123456789";
		firstNameTest = "Matthew";
		lastNameTest = "Trembley";
		NumberTest = "6035550554";
		AddressTest = "1095 Main Street, Manchester";
		tooLongContact = "123456891010";
		tooLongFirstName = "Matthewaaaa";
		tooLongLastName = "Trembleeeeeeey";
		tooLongNumber = "1603515150554";
		tooShortNumber = "603";
		tooLongAddress = "1095 Main Street, Manchester, New Hampshire";
		
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testGetContactId() { 
		assertNotNull(contactId); //assert true that value is not null
		int length = String.valueOf(contactId).length();
		assertTrue(length < 10); //assert true that the length of contactId is less than 10
		int tooLong = String.valueOf(tooLongContact).length();
		assertTrue(tooLong > 10); //assert true that the length of tooLongContact is greater than 10
	}

	@Test
	void testGetFirstName() {
		assertNotNull(firstNameTest);
		int length = String.valueOf(firstNameTest).length();
		assertTrue(length < 10);
		int tooLong = String.valueOf(tooLongFirstName).length();
		assertTrue(tooLong > 10);
	}

	@Test
	void testGetLastName() {
		assertNotNull(lastNameTest);
		int length = String.valueOf(lastNameTest).length();
		assertTrue(length < 10);
		int tooLong = String.valueOf(tooLongLastName).length();
		assertTrue(tooLong > 10);
	}

	@Test
	void testGetNumber() {
		assertNotNull(NumberTest);
		int length = String.valueOf(NumberTest).length();
		assertTrue(length == 10);
		int tooLong = String.valueOf(tooLongNumber).length();
		assertTrue(tooLong > 10);
		int tooShort  = String.valueOf(tooShortNumber).length();
		assertTrue(tooShort < 10);
	}

	@Test
	void testGetAddress() {
		assertNotNull(AddressTest);
		int length = String.valueOf(AddressTest).length();
		assertTrue(length < 30);
		int tooLong = String.valueOf(tooLongAddress).length();
		assertTrue(tooLong > 30);
	}

	@Test
	void testUpdateContactId() { //updates contactId, and asserts that it is assigned to a value, that it is not "empty", and that it is not null or too long
		Contact contact = new Contact(); //this applies for the rest of updateFirstName, LastName, Address, Number
		contact.updateContactId(contactId);
		assertNotNull(contactId);
		assertNotEquals(contactId, "empty");
		assertAll(
		() -> assertEquals(contactId, contact.getContactId()),
		() -> assertThrows(IllegalArgumentException.class,
				() -> contact.updateContactId(null)),
		() -> assertThrows(IllegalArgumentException.class,
				() -> contact.updateContactId(tooLongContact)));
		
	}

	@Test
	void testUpdateFirstName() {
		Contact contact = new Contact();
		contact.updateFirstName(firstNameTest);
		assertNotNull(firstNameTest);
		assertNotEquals(firstNameTest, "empty");
		assertAll(
		() -> assertEquals(firstNameTest, contact.getFirstName()),
		() -> assertThrows(IllegalArgumentException.class,
				() -> contact.updateFirstName(null)),
		() -> assertThrows(IllegalArgumentException.class,
				() -> contact.updateFirstName(tooLongFirstName)));
	}

	@Test
	void testUpdateLastName() {
		Contact contact = new Contact();
		contact.updateLastName(lastNameTest);
		assertNotNull(lastNameTest);
		assertNotEquals(lastNameTest, "empty");
		assertAll(
		() -> assertEquals(lastNameTest, contact.getLastName()),
		() -> assertThrows(IllegalArgumentException.class,
				() -> contact.updateLastName(null)),
		() -> assertThrows(IllegalArgumentException.class,
				() -> contact.updateLastName(tooLongLastName)));
	}

	@Test
	void testUpdateNumber() {
		Contact contact = new Contact();
		contact.updateNumber(NumberTest);
		assertNotNull(NumberTest);
		assertNotEquals(NumberTest, "empty");
		assertAll(
		() -> assertEquals(NumberTest, contact.getNumber()),
		() -> assertThrows(IllegalArgumentException.class,
				() -> contact.updateNumber(null)),
		() -> assertThrows(IllegalArgumentException.class,
				() -> contact.updateNumber(tooLongNumber)),
		() -> assertThrows(IllegalArgumentException.class,
				() -> contact.updateNumber(tooShortNumber)));
	}

	@Test
	void testUpdateAddress() {
		Contact contact = new Contact();
		contact.updateAddress(AddressTest);
		assertNotNull(AddressTest);
		assertNotEquals(AddressTest, "empty");
		assertAll(
		() -> assertEquals(AddressTest, contact.getAddress()),
		() -> assertThrows(IllegalArgumentException.class,
				() -> contact.updateAddress(null)),
		() -> assertThrows(IllegalArgumentException.class,
				() -> contact.updateAddress(tooLongAddress)));
	}

}
