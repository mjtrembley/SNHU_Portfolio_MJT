import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ContactServiceTest {
	private String contactId, firstNameTest, lastNameTest, NumberTest, AddressTest, tooLongContact, tooLongFirstName, 
	tooLongLastName, tooLongNumber,tooLongAddress; //establish each variable to use
	@BeforeEach
	void setUp() throws Exception {
		contactId = "123456789";
		firstNameTest = "Matthew";
		lastNameTest = "Trembley";
		NumberTest = "6035550554";
		AddressTest = "1095 Main Street, Manchester";
		tooLongContact = "123456891010";
		tooLongFirstName = "Matthewaaaa";
		tooLongLastName = "Trembleeeeeeey";
		tooLongNumber = "1603515150554";
		tooLongAddress = "1095 Main Street, Manchester, New Hampshire";
	 }
	
	@Test
	void testAddNewContact() { //test case for each new "contact" up until each variable is filled. 
		ContactService service = new ContactService();
		service.addNewContact();
		assertAll(
				() -> assertNotNull(service.seeList().get(0).getContactId()),
				() -> assertEquals("empty",
						service.seeList().get(0).getFirstName()),
				() -> assertEquals("empty",
						service.seeList().get(0).getLastName()),
				() -> assertEquals("empty", 
						service.seeList().get(0).getNumber()),
				() -> assertEquals("empty",
						service.seeList().get(0).getAddress()));
		service.addNewContact(firstNameTest);
		assertAll(
				() -> assertNotNull(service.seeList().get(1).getContactId()),
				() -> assertEquals("Matthew",
						service.seeList().get(1).getFirstName()),
				() -> assertEquals("empty",
						service.seeList().get(1).getLastName()),
				() -> assertEquals("empty", 
						service.seeList().get(1).getNumber()),
				() -> assertEquals("empty",
						service.seeList().get(1).getAddress()));
		service.addNewContact(firstNameTest, lastNameTest);
		assertAll(
				() -> assertNotNull(service.seeList().get(2).getContactId()),
				() -> assertEquals("Matthew",
						service.seeList().get(2).getFirstName()),
				() -> assertEquals("Trembley",
						service.seeList().get(2).getLastName()),
				() -> assertEquals("empty", 
						service.seeList().get(2).getNumber()),
				() -> assertEquals("empty",
						service.seeList().get(2).getAddress()));
		service.addNewContact(firstNameTest, lastNameTest, NumberTest);
		assertAll(
				() -> assertNotNull(service.seeList().get(3).getContactId()),
				() -> assertEquals("Matthew",
						service.seeList().get(3).getFirstName()),
				() -> assertEquals("Trembley",
						service.seeList().get(3).getLastName()),
				() -> assertEquals("6035550554", 
						service.seeList().get(3).getNumber()),
				() -> assertEquals("empty",
						service.seeList().get(3).getAddress()));
		service.addNewContact(firstNameTest, lastNameTest, NumberTest, AddressTest);
		assertAll(
				() -> assertNotNull(service.seeList().get(4).getContactId()),
				() -> assertEquals("Matthew",
						service.seeList().get(4).getFirstName()),
				() -> assertEquals("Trembley",
						service.seeList().get(4).getLastName()),
				() -> assertEquals("6035550554", 
						service.seeList().get(4).getNumber()),
				() -> assertEquals("1095 Main Street, Manchester",
						service.seeList().get(4).getAddress()));
	}

	@Test
	void testDeleteContact() { //deletes contactId, but then searches for it under seeList().get(0) to make sure it was removed from list
		 ContactService service = new ContactService();
		    service.addNewContact();
		    assertThrows(Exception.class, () -> service.deleteContact(contactId));
		    assertAll(
		    		()-> service.deleteContact(service.seeList().get(0).getContactId()));
	}

	@Test
	void testUpdateFirstName() throws Exception { //adds new contact, then updates first name with firstNameTest. Then compares to tooLong, null, and contactId to
		ContactService service = new ContactService(); //ensure that it is the correct value. Applies to updateLastName, Address, and Number.
	    service.addNewContact();
	    service.updateFirstName(service.seeList().get(0).getContactId(),firstNameTest);
	    assertEquals(firstNameTest, service.seeList().get(0).getFirstName());
	    assertThrows(IllegalArgumentException.class,
	    		()-> service.updateFirstName(service.seeList().get(0).getContactId(),tooLongFirstName));
	    assertThrows(IllegalArgumentException.class,
	            ()-> service.updateFirstName(service.seeList().get(0).getContactId(), null));
	    assertThrows(Exception.class,
	    		()-> service.updateFirstName(contactId, firstNameTest));
	}

	@Test
	void testUpdateLastName() throws Exception {
		ContactService service = new ContactService();
	    service.addNewContact();
	    service.updateLastName(service.seeList().get(0).getContactId(),lastNameTest);
	    assertEquals(lastNameTest, service.seeList().get(0).getLastName());
	    assertThrows(IllegalArgumentException.class,
	    		()-> service.updateLastName(service.seeList().get(0).getContactId(),tooLongLastName));
	    assertThrows(IllegalArgumentException.class,
	            ()-> service.updateLastName(service.seeList().get(0).getContactId(), null));
	    assertThrows(Exception.class,
	    		()-> service.updateLastName(contactId, lastNameTest));
	}

	@Test
	void testUpdateNumber() throws Exception {
		ContactService service = new ContactService();
		service.addNewContact();
		service.updateNumber(service.seeList().get(0).getContactId(), NumberTest);
		assertEquals(NumberTest, service.seeList().get(0).getNumber());
		assertThrows(IllegalArgumentException.class,
	    		()-> service.updateNumber(service.seeList().get(0).getContactId(),tooLongNumber));
	    assertThrows(IllegalArgumentException.class,
	            ()-> service.updateNumber(service.seeList().get(0).getContactId(), null));
	    assertThrows(Exception.class,
	    		()-> service.updateNumber(contactId, NumberTest));
	}

	@Test
	void testUpdateAddress() throws Exception {
		ContactService service = new ContactService();
		service.addNewContact();
		service.updateAddress(service.seeList().get(0).getContactId(), AddressTest);
		assertEquals(AddressTest, service.seeList().get(0).getAddress());
		assertThrows(IllegalArgumentException.class,
	    		()-> service.updateAddress(service.seeList().get(0).getContactId(),tooLongAddress));
	    assertThrows(IllegalArgumentException.class,
	            ()-> service.updateAddress(service.seeList().get(0).getContactId(), null));
	    assertThrows(Exception.class,
	    		()-> service.updateAddress(contactId, AddressTest));
	}

}
