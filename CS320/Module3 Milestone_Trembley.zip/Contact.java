public class Contact {

private String contactId;
private String firstName;
private String lastName;
private String Number;
private String Address;
private String empty = "empty";

Contact(){
	this.contactId = empty;
	this.firstName = empty;
	this.lastName = empty;
	this.Number = empty;
	this.Address = empty;
}
public String getContactId() { return contactId;}
public String getFirstName() { return firstName;}
public String getLastName() { return lastName;}
public String getNumber() { return Number;}
public String getAddress() {return Address;}
	
Contact(String contactId){
	updateContactId(contactId);
	this.firstName = empty;
	this.lastName = empty;
	this.Number = empty;
	this.Address = empty;
	
	}
Contact(String contactId, String firstName){
	updateContactId(contactId);
	updateFirstName(firstName);
	this.lastName = empty;
	this.Number = empty;
	this.Address = empty;
	}
Contact(String contactId, String firstName, String lastName){
	updateContactId(contactId);
	updateFirstName(firstName);
	updateLastName(lastName);
	this.Number = empty;
	this.Address = empty;
}
Contact(String contactId, String firstName, String lastName, String Number){
	updateContactId(contactId);
	updateFirstName(firstName);
	updateLastName(lastName);
	updateNumber(Number);
	this.Address = empty;
	}
Contact(String contactId, String firstName, String lastName, String Number, String Address){
	updateContactId(contactId);
	updateFirstName(firstName);
	updateLastName(lastName);
	updateNumber(Number);
	updateAddress(Address);
	}

public void updateContactId(String contactId){
	if (contactId == null) {
		throw new IllegalArgumentException("Contact ID cannot be null/empty");
	} else if (contactId.length() > 10) {
		throw new IllegalArgumentException("Contact ID cannot be longer than 10 characters");
	} else {	
		this.contactId = contactId;
	}
  }
public void updateFirstName(String firstName) {
	if (firstName == null) {
		throw new IllegalArgumentException("First name cannot be null/empty");
	} else if (firstName.length() >= 10 ) {
		throw new IllegalArgumentException("First name cannot be longer than 10 characters");
	} else {
		this.firstName = firstName;
	}
  }
public void updateLastName(String lastName) {
	if (lastName == null) {
		throw new IllegalArgumentException("Last name cannot be null/empty");
	} else if (lastName.length() >= 10 ) {
		throw new IllegalArgumentException("Last name cannot be longer than 10 characters");
	} else {
		this.lastName = lastName;
	}
  }
public void updateNumber(String Number) {
	if (Number == null) {
		throw new IllegalArgumentException("Phone number cannot be null/empty");
	} else if (Number.length() > 10 ) {
		throw new IllegalArgumentException("Phone number cannot be longer than 10 characters");
	} else if (Number.length() < 10 ) {
		throw new IllegalArgumentException("Phone number must be 10 characters long.");
	} else {
		this.Number = Number;
	}
  }
public void updateAddress(String Address) {
	if (Address == null) {
		throw new IllegalArgumentException("Address cannot be null/empty");
	} else if (Address.length() >= 30 ) {
		throw new IllegalArgumentException("Address cannot be longer than 30 characters");
	} else {
		this.Address = Address;
	}
  }
}
