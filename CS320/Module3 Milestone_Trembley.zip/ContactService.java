
import java.util.List;
import java.util.ArrayList;
import java.util.UUID;


public class ContactService {

		private UUID id;
		private String uniqueContactId;
		private List<Contact> contactList = new ArrayList<Contact>();
		
		
{
	id = UUID.randomUUID();
	uniqueContactId = id.toString().substring(0, 10); //https://stackoverflow.com/questions/20679964/unique-alphanumeric-string-with-a-fixed-length
	
}
private String newId() {
	return uniqueContactId;
}
private Contact contactSearch(String uniqueContactId) throws Exception { //method to find a contact for deleting or updating
    int i = 0;
    while (i < contactList.size()) {
      if (uniqueContactId.equals(contactList.get(i).getContactId())) {
        return contactList.get(i);
      } i++;
    }
    throw new Exception("The contact could not be found."); //throw exception if contact could not be found 
  }

public List<Contact> seeList(){return contactList;} //print list of contacts to screen

public void addNewContact() { 
	Contact contact = new Contact(newId());
	contactList.add(contact);
}
public void addNewContact(String firstName) {
	 Contact contact = new Contact(newId(), firstName);
	 contactList.add(contact);
}
public void addNewContact(String firstName, String lastName) {
	 Contact contact = new Contact(newId(), firstName, lastName);
	 contactList.add(contact);
}
public void addNewContact(String firstName, String lastName, String Number) {
	 Contact contact = new Contact(newId(), firstName, lastName, Number);
	 contactList.add(contact);
}
public void addNewContact(String firstName, String lastName, String Number, String Address) {
	 Contact contact = new Contact(newId(), firstName, lastName, Number, Address);
	 contactList.add(contact);
}

public void deleteContact(String uniqueContactId) throws Exception {
	contactList.remove(contactSearch(uniqueContactId));
}
public void updateFirstName(String uniqueContactId, String firstName) throws Exception {
	 contactSearch(uniqueContactId).updateFirstName(firstName);
}
public void updateLastName(String uniqueContactId, String LastName) throws Exception {
	 contactSearch(uniqueContactId).updateLastName(LastName);
}
public void updateNumber(String uniqueContactId, String Number) throws Exception {
	contactSearch(uniqueContactId).updateNumber(Number);
}
public void updateAddress(String uniqueContactId, String Address) throws Exception {
	contactSearch(uniqueContactId).updateAddress(Address);
}
}